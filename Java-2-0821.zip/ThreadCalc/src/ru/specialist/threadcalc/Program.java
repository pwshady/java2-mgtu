package ru.specialist.threadcalc;

import java.util.Scanner;
import static java.lang.System.out;

public class Program {
	
	static int summa = 0;
	
	public static void main(String[] args) throws InterruptedException 
	{
		out.print("�����: ");
		Scanner sc = new Scanner(System.in);
		final int n = sc.nextInt();
		sc.close();
		
		(new Thread(
			()->{
				//int summa = 0;
				for(int i=1; i <= n; i++)
					summa += i;
				
				
			}
		)).start();
		
		// Thread.sleep(1000);
		
		out.println(summa);

	}

}
