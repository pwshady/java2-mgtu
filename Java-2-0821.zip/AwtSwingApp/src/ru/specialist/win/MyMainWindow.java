package ru.specialist.win;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Label;
import java.awt.Component;
import javax.swing.Box;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class MyMainWindow {

	private JFrame frame;
	private Label label;
	private JLabel labelHello;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyMainWindow window = new MyMainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MyMainWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		label = new Label("Status line");
		frame.getContentPane().add(label, BorderLayout.SOUTH);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblName.setBounds(10, 11, 75, 27);
		panel.add(lblName);
		
		JTextField textUserName = new JTextField();
		textUserName.setFont(new Font("Tahoma", Font.PLAIN, 22));
		textUserName.setBounds(95, 11, 243, 27);
		panel.add(textUserName);
		textUserName.setColumns(10);
		
		JButton btnHello = new JButton("Hello");
		btnHello.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = textUserName.getText();
				String result = String.format("Hello, %s!", userName);
				labelHello.setText(result);
			}
		});
		btnHello.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnHello.setBounds(341, 11, 91, 27);
		panel.add(btnHello);
		
		labelHello = new JLabel("Hello!");
		labelHello.setHorizontalAlignment(SwingConstants.CENTER);
		labelHello.setForeground(Color.RED);
		labelHello.setFont(new Font("Dialog", Font.BOLD, 22));
		labelHello.setBounds(10, 92, 422, 32);
		panel.add(labelHello);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("File");
		menuBar.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Exit");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (JOptionPane.showConfirmDialog(frame, "Realy quit?", "Quit?",
						JOptionPane.YES_NO_OPTION ) == JOptionPane.YES_OPTION)
					System.exit(0);
			}
		});
		menuBar.add(mntmNewMenuItem_1);
	}
}
