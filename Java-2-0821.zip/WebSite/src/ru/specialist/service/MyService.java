package ru.specialist.service;

import java.util.Date;

public class MyService {
	
	public String time()
	{
		Date now = new Date();
		return now.toLocaleString();
		
	}

}
