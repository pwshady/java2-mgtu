import java.rmi.RemoteException;

import ru.specialist.service.*;
public class Program {

	public static void main(String[] args) throws RemoteException {
		MyService proxy = new MyServiceProxy("http://localhost:8080/WebSite/services/MyService");
		
		System.out.println(proxy.time());

	}

}
