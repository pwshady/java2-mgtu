package ru.specialist.tree;

public class TreeNode {
	
	public TreeNode left;
	public TreeNode right;
	
	public int weight; 

}
