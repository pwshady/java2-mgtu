package ru.specialist.calc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MyCalc {

	private JFrame frame;
	private JComboBox listOp;
	private JTextField txt2;
	private JTextField txt1;
	private JLabel labelResult;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				MyCalc window = new MyCalc();
				window.frame.setVisible(true);
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MyCalc() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txt1 = new JTextField();
		txt1.setBounds(10, 30, 86, 20);
		frame.getContentPane().add(txt1);
		txt1.setColumns(10);
		
		listOp = new JComboBox();
		listOp.setModel(new DefaultComboBoxModel(new String[] {"+", "-", "*", "/"}));
		listOp.setBounds(104, 29, 46, 22);
		frame.getContentPane().add(listOp);
		
		txt2 = new JTextField();
		txt2.setBounds(156, 30, 74, 20);
		frame.getContentPane().add(txt2);
		txt2.setColumns(10);
		
		JButton btnNewButton = new JButton("=");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					double x1 = Double.parseDouble(txt1.getText());
					double x2 = Double.parseDouble(txt2.getText());
					String op = listOp.getSelectedItem().toString();
					double xr = 0d;
					switch(op)
					{
						case "+" : xr = x1 + x2; break;
						case "-" : xr = x1 - x2; break;
						case "*" : xr = x1 * x2; break;
						case "/" : xr = x1 / x2; break;
					}
					
					labelResult.setText(String.valueOf(xr));
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", 
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(244, 29, 54, 23);
		frame.getContentPane().add(btnNewButton);
		
		labelResult = new JLabel("New label");
		labelResult.setBounds(347, 33, 46, 14);
		frame.getContentPane().add(labelResult);
	}
}
