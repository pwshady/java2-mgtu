package ru.specialist.fx;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class MyController {
	
	@FXML
	private Label labelResult;
	
	@FXML
	private TextField txtUserName;
	
	@FXML
	private void  onButtonClick()
	{
		String userName = txtUserName.getText();
		String result = String.format("Hello, %s!", userName);
		labelResult.setText(result);
	}
	
}
