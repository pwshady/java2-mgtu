
import java.util.concurrent.*;

public class Program {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService pool = Executors.newWorkStealingPool( Runtime.getRuntime().availableProcessors() );
				
				//.newCachedThreadPool();
				//.newFixedThreadPool(5);
				//.newSingleThreadExecutor()
		
		long t1 = System.currentTimeMillis();
		
		Future[] tasks = new Future[10];
		for(int i=0; i < 10; i++)
			tasks[i] = pool.submit(new MyCallTask());
		
		//Thread.sleep(70000);
		//pool.shutdownNow();
		Thread.sleep(10);
		tasks[0].cancel(true);
		
		Future<Long> t11 = pool.submit(new MyCallTask());
		Future<Long> t12 = pool.submit(new MyCallTask());
		
		for(Future<?> t : tasks)
		{
			if (t.isCancelled())
				System.out.println("canceled");
			else
				System.out.println(t.get());
		}
		
		System.out.println(t11.get());
		System.out.println(t12.get());
		
		long t2 = System.currentTimeMillis();
		System.out.printf("Time (ms): %d\n", t2-t1);
		
		pool.shutdown();
		

	}

}
