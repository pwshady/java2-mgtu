import java.io.*;
import java.net.*;
import java.nio.charset.Charset;

import static java.lang.System.out;


public class Main {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws IOException, InterruptedException {
		ServerSocket ss = new ServerSocket(1111);
		
		while (true)
		{
			Socket cs = ss.accept();
			
			out.printf("Accept connection from %s\n",
					cs.getInetAddress().toString());
			
			BufferedReader reader = new BufferedReader( 
				new InputStreamReader(cs.getInputStream(), 
					Charset.forName("UTF-8")));
			
			String s = reader.readLine();
			
			out.println(s);
			Thread.sleep(2000);
			
			OutputStreamWriter writer = new OutputStreamWriter(
					cs.getOutputStream(),
					Charset.forName("UTF-8"));
			
			writer.write(s.toUpperCase()+"\n");
			writer.flush();
			
			if (s.equals("stop"))
			{
				ss.close();
				writer.close();
				cs.close();
				break;
			}
			
			
			
			
		}

	}

}
